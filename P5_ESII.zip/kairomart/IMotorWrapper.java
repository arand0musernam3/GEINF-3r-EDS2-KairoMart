public interface IMotorWrapper {

	void setWrappee(IMotor motor);

}
