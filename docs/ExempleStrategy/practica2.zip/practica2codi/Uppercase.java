public class Uppercase implements TextFormatter {
	@Override
	public String format(String str) {
		return str.toUpperCase();
	}
}
