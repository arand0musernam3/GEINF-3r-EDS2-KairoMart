public interface TextFormatter {
	String format(String str);
}
