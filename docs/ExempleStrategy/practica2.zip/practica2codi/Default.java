public class Default implements TextFormatter {
	public String format(String str) {
		return str;
	}
}
